from django.contrib import admin
from django.urls import path, include
from .views import transpunere, insereaza_matrice, transpunere_js

# app_name = 'matrici'

urlpatterns = [
    path('transpus/', transpunere),
    path('form/', insereaza_matrice),
    path('formjs/', transpunere_js),
]