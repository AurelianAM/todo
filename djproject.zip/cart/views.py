from django.shortcuts import render, redirect
from .cart import Cart
# from store.models import Product
# Create your views here.

def cart_view(request):

    print('Sesiunea din cart: ', request.session)
    print('Utilizatorul din esiunea din cart: ', request.user)

    # # # Doar de test pentru a vedea ca se pastreaza
    # # # valoare, pe sesiune
    # # request.session['test'] = 'Test value'
    # print(request.session['test'])

    # current_cart = Cart(request)

    # nr_produse = len(current_cart)
    # print(nr_produse)

    # # logica asta o mutam in cart
    # # products_dict = current_cart.products
    # # products = Product.objects.filter(pk__in=products_dict.keys())
    # # si atunci:
    # products = current_cart.products
    # total = current_cart.total
    # context = {'nr_produse' : nr_produse, 'products' : products, 'total' : total}

    return render(request, 'cart.html') # am sters context din render - dupa introducerea procesatorului

def clear_cart_view(request):
    current_cart = Cart(request)
    current_cart.clear_cart()
    return redirect('cart:cart_view')

def add_product_to_cart_view(request, product):
    print('cantitatea: ', request.POST.get('quantity'))
    current_cart = Cart(request)
    # cantitatea - get-ul o da ca string, deci trebuie transofrmata
    qty = int(request.POST.get('quantity', 1))
    current_cart.add_product(product, qty)
    return redirect('cart:cart_view')
