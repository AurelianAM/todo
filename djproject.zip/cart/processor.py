# acesta este procesator de context

from .cart import Cart

def cart_processor(request):

    current_cart = Cart(request)

    nr_produse = len(current_cart)
    # print(nr_produse)

    products = current_cart.products
    total = current_cart.total

    context = {'nr_produse' : nr_produse, 'products' : products, 'total' : total}

    return context

