from store.models import Product

class Cart:

    def __init__(self, request):
        self.session = request.session
        self.session['products'] = self.session.get('products', {})
    
    def __len__(self):
        nr = 0
        for product in self.session['products']:
            nr +=  self.session['products'][product]
        return nr
    
    @property
    def products(self):
        products_dict = self.session['products']
        return Product.objects.filter(pk__in=products_dict.keys())
    
    @property
    def total(self):
        _total = 0
        for product in self.products:
            _total += (product.price * self.session['products'].get(str(product.id), 1))
        return _total

    def add_product(self, product, quantity):
        product = str(product)
        self.session['products'][product] = quantity + self.session['products'].get(product, 0)
        self.save()
    
    def clear_cart(self):
        print('Should empty cart...')
        del self.session['products']
        self.session['products'] = {}
        self.save()
    
    def save(self):
        self.session.modified = True

