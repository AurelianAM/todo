import csv
import weasyprint
from django.shortcuts import render, get_object_or_404
from .models import Product
from django.http import JsonResponse, HttpResponse
from cart.cart import Cart
# Create your views here.

def store_list_view(request):
    print(request.GET.get("search"))
    search = request.GET.get("search")
    if search:
        products = Product.objects.filter(title__contains=search) 
    else:
        products =  Product.objects.all()
    return render(request, 'store_list.html', {'products':products})

def store_details_view(request, slug):
    cart = Cart(request)
    product_details = get_object_or_404(Product, slug=slug)
    context = {'product': product_details, 'cart':cart, 'choices': range(1,11)}
    return render(request, 'store_details.html', context)
 
def jsonproducts_view(request):
    products =  list(Product.objects.all())
    products = [ {"nume":product.name, "pret":product.price}   for product in products  ]
    return JsonResponse({"products": products})


def csvproducts_view(request):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] =  'attachment; filename="products.csv"'
    writer = csv.writer(response)
    writer.writerow(('Titlu', 'Slug', 'Pret', 'Description'))
    products =  list(Product.objects.all())
    for prod in products:
        writer.writerow((prod.name, prod.slug, prod.price, prod.description))
    return response


def pdfproducts_view(request):
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] =  'attachment; filename="products.pdf"'

    
    html_string = ""
    products =  list(Product.objects.all())
    for prod in products:
        html_string += f"<h1>{prod.name} - {prod.price} </h1>"

    weasyprint.HTML(string=html_string).write_pdf(response)
    return response


def xml_view(request):
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] =  'attachment; filename="products.pdf"'

    
    html_string = ""
    products =  list(Product.objects.all())
    for prod in products:
        html_string += f"<h1>{prod.get_absolute_url()} </h1>"

    weasyprint.HTML(string=html_string).write_pdf(response)
    return response


def cookie_view(request):
    response = HttpResponse('<h1>Ai o prajitura</h1>')
    # response.set_cookie('salut_cookie', 'valoare_cookie')
    # sau asa
    request.COOKIES['cheie_noua_cookie'] = 'valoare_cookie'
    # asa iau cookie-urile
    print('Cookies: ', request.COOKIES)
    return response

def session_view(request):
    request.session['cheie_sesiune'] = 'valoare_sesiune'
    response = HttpResponse('<h1>Ai o sesiune</h1>')

    return response