from django.db import models

# Create your models here.


class TodoItem(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    is_completed = models.BooleanField(default=False)
    created = models.DateTimeField(auto_now=True)
    updated = models.DateTimeField(null=True)
    # aici ar trebui facute foreigh key user_id = models....

    def __str__(self):
        return self.title
    

