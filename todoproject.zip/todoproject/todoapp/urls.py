from django.contrib import admin
from django.urls import path, include
from .views import *

urlpatterns = [
    path('', home_view, name='home'),
    path('about/', about_view, name='about'),
    path('add/', create_todo_view, name='add'),
]