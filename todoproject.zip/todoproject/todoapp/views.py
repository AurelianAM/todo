from django.shortcuts import render, redirect
from .models import TodoItem
from .form import TodoItemForm
# Create your views here.

def home_view(request):
    todos = TodoItem.objects.all()
    context = {'todos' : todos}
    return render(request, 'home.html', context)

def about_view(request):
    return render(request, 'about.html')

def create_todo_view(request):
    if request.method == 'POST':
        print('request.POST = ', request.POST)
        form = form = TodoItemForm(request.POST)

        if form.is_valid():

            new_todo = form.save()
            print('Noul TODO: ', new_todo)
            new_todo.save()

            return redirect('home')
        
        else:
            return render(request, 'createtodo.html',{'form' : form})
    
    else:     
        form = TodoItemForm()
        return render(request, 'createtodo.html',{'form' : form})