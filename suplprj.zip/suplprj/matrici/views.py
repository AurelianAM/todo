from django.shortcuts import render, redirect
import numpy as np
from django.http import HttpResponse
import pickle

# Create your views here.
def logica_de_business(matrice):
    m_initial = np.array(matrice)
    print('Asta este matricea preluata din numpy')
    for rand in m_initial:
        print(rand)
    m_transpus = m_initial.transpose()
    matrice_transpusa = m_transpus.tolist() #sau: m_transpus.tolist() # list(m_transpus)
    return matrice, matrice_transpusa

def transpunere(request):
    # matrice = [[10, 20, 30], [40, 50, 60], [70, 80, 90]]
    with open('matrice.pk', 'rb') as f:
        matrice = pickle.load(f)
    print('Asta este matricea preluata din pickle')
    for rand in matrice:
        print(rand)
    matrice, matrice_transpusa = logica_de_business(matrice)
    context ={
        'paragraph' : logica_de_business(matrice),
        'matrice_initial':matrice,
        'matrice_transpusa':matrice_transpusa,
        'rows' : len(matrice),
        'columns' : len(matrice[0])
    }
    return render(request, 'transpunere.html', context=context)

def insereaza_matrice(request):
    if request.method == 'POST':
        print(request)
        print(request.POST)
        
        keys = [key for key in request.POST if key != 'csrfmiddlewaretoken']
        prime_litere = [int(key[0]) for key in keys]
        ultime_litere = [int(key[1]) for key in keys]
        columns = max(ultime_litere)
        rows = max(prime_litere)
        print('max_columns: ', columns)
        print('max_rows: ', rows)

        matrice = [[None for j in range(columns+1)] for i in range(rows+1)]

        print(matrice)
        for i in range(rows + 1):
            for j in range(columns + 1):
                valoare = request.POST.get(f'{i}{j}')
                matrice[i][j] = valoare
        print(matrice)

        with open('matrice.pk', 'wb') as f:
            pickle.dump(matrice, f)

        return redirect(transpunere)
        # for key in request.POST:
        #     if key != 'csrfmiddlewaretoken':
        #         print(key)
        # return HttpResponse('Am primit, multumesc!')   
        # return redirect(transpunere, matrice=matrice)
        # return redirect('matrici:transpunere', matrice=matrice)
        # return redirect(reverse('transpunere', kwargs={"matrice": matrice}))
    else:
        rows = request.GET.get('rows', 3)
        columns = request.GET.get('columns', 3)
        try:
            rows = int(rows)
            columns = int(columns)
        except:
            rows = 3
            columns = 3
            print('Nu se poate...')
        inputs = [f'{i}{j}' for i in range(rows) for j in range(columns)]
        context = {
            'inputs':inputs,
            'columns':columns, 'rows':rows}
        return render(request, 'formular_matrice.html', context)