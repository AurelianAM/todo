from django.contrib import admin
from django.urls import path, include
from .views import transpunere, insereaza_matrice

# app_name = 'matrici'

urlpatterns = [
    path('transpus/', transpunere),
    path('form/', insereaza_matrice),
]